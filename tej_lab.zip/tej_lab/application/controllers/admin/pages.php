<?php

class Pages extends CI_controller {

    function __construct() {
        parent::__construct();
        $this->load->model('pages_model');
    }

    function index() {
        $data['query'] = $this->get('page_title');
        $this->load->view('admin/pages/index', $data);
    }

    function get_data_from_post() {
        $data['page_title'] = $this->input->post('page_title', TRUE);
        $data['description'] = $this->input->post('description', TRUE);
        $data['page_content'] = $this->input->post('page_content', TRUE);
        return $data;
    }

    function get_data_from_db($update_id) {
        $query = $this->get_where($update_id);
        foreach ($query->result() as $row) {
            $data['page_title'] = $row->page_title;
            $data['description'] = $row->description;
            $data['page_content'] = $row->page_content;
        }
        if (!isset($data)) {
            $data = '';
        }
        return $data;
    }

    function create() {
        $update_id = $this->uri->segment(4);
        $submit = $this->input->post('submit', TRUE);
        if ($submit == "Submit") {
            $data = $this->get_data_from_post();
        } else {
            if (is_numeric($update_id)) {
                $data = $this->get_data_from_db($update_id);
            }
        }
        if (!isset($data)) {
            $data = $this->get_data_from_post();
        }
        $data['update_id'] = $update_id;
        $this->load->view('admin/pages/create', $data);
    }

    function submit() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('page_title', 'Page Title', 'required|xss_clean');
        $this->form_validation->set_rules('page_content', 'Page Content', 'required|xss_clean');
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = $this->get_data_from_post();
            $data['page_url'] = url_title($data['page_title']);
            $update_id = $this->uri->segment(4);
            if (is_numeric($update_id)) {
                $this->_update($update_id, $data);
            } else {
                $this->_insert($data);
            }
            redirect('admin/pages/index');
        }
    }

    function get($order_by) {
        $query = $this->pages_model->get($order_by);
        return $query;
    }

    function get_with_limit($limit, $offset, $order_by) {
        $query = $this->pages_model->get_with_limit($limit, $offset, $order_by);
        return $query;
    }

    function get_where($id) {
        $query = $this->pages_model->get_where($id);
        return $query;
    }

    function get_where_custom($col, $value) {
        $query = $this->pages_model->get_where_custom($col, $value);
        return $query;
    }

    function _insert($data) {
        $this->pages_model->_insert($data);
    }

    function _update($id, $data) {
        $this->pages_model->_update($id, $data);
    }

    function delete($id) {
        $this->pages_model->_delete($id);
        redirect('admin/pages');
    }

}

?>