    <hr/>
    <footer>
        <div style="text-align:center;"><a href="http://phoenixsolution.com" target="_blank" alt="Driven By Phoenix Solutions" style="width:120px;">Phoenix Solution Pvt.Ltd.</a></div>
    </footer>
</div>

</body>
</html>