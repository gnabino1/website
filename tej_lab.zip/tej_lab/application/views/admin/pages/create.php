<?php include('../header.php');?><h2>Create Page</h2>
<div id="form">

    <?php echo validation_errors("<p style='color:red;'>","</p>"); 
        echo form_open('admin/pages/submit/'.$update_id); ?>
    
    <table width="900" border="1" >
        <tr>
            <td>
                Page Title:
                <?php 
                $data=array(
                    'name'=>'page_title',
                    'value'=>$page_title,
                   'maxlength'=>'100',);
                  echo form_input($data);  
                ?>
            </td>
        </tr>
        <tr>
            <td>
                Description:
                <?php 
                $data=array(
                    'name'=>'description',
                    'value'=>$description,
                   'maxlength'=>'100',);
                  echo form_input($data);  
                ?>
            </td>
        </tr>
        <tr>
            <td>
                Page Content:
                <?php 
                $data=array(
                    'name'=>'page_content',
                    'value'=>$page_content,
                    'rows'=>'50',
                    'cols'=>'20',);
                  echo form_input($data);  
                ?>
            </td>
        </tr>
        <tr><td colspan="2" align="center"><?php echo form_submit('submit','Submit');?></tr>
    </table>
      <?php echo form_close();     ?>

</div>
<?php include_once '../footer.php';?>