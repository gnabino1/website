<?php include('../header.php')?><?php echo "Pages"?>
<?php
echo anchor('admin/pages/create','<p>Create New Page</p>');
?>
<table width="600" cellspacing="0" cellpadding="8">
    <tr style="background-color:navy;color:white;"><th>Page Headline</th><th>Edit</th><th>Delete</th></tr>
    <?php
        foreach($query->result() as $row){
        
        $edit_url=base_url().'index.php/admin/pages/create/'.$row->id;
      ?>
    <tr><td><?php echo $row->page_title ;?></td><td><?php echo anchor($edit_url,'Edit')?></td>
        <td ><a href= "<?php echo base_url().'index.php/admin/pages/delete/'.$row->id;?>" onclick="return areyousure();">Delete</a></td></tr>
    <?php 
    }
    ?>
    </table> 
<?php include('../footer.php')?>
<script type="text/javascript">
function areyousure()
{
	return confirm('<?php echo lang('confirm_delete');?>');
}
</script>
